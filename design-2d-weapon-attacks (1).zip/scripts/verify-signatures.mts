import assert from "node:assert/strict";
import { mkdirSync, writeFileSync } from "node:fs";
import { createCanvas } from "@napi-rs/canvas";

Object.assign(globalThis, {
  window: { devicePixelRatio: 1 },
  document: { createElement: () => createCanvas(1, 1) },
});
const { Game, WEAPONS } = await import("../src/game/engine");
const { FIRE_SPECS, fireMotion, firingMuzzleOffset } =
  await import("../src/game/fireMotion");
const { measureWeapon } = await import("../src/game/measure");
const { audio, emissionCount } = await import("../src/game/core");
audio.muted = true;
mkdirSync(".checks", { recursive: true });

function makeGame() {
  const canvas = createCanvas(1100, 700) as any;
  canvas.getBoundingClientRect = () => ({ width: 1100, height: 700 });
  const game = new Game(canvas);
  game.rotation = 0.2;
  game.dir = 1;
  return game;
}

const ids = Object.keys(FIRE_SPECS) as (keyof typeof FIRE_SPECS)[];
const sheet = createCanvas(6 * 320, ids.length * 210);
const context = sheet.getContext("2d");
context.fillStyle = "#101c26";
context.fillRect(0, 0, sheet.width, sheet.height);
const phases = [
  "REST",
  "ANTICIPATION",
  "RELEASE",
  "RECOIL",
  "RECOVERY",
  "SETTLED",
];
for (const fps of [30, 60, 144]) {
  let particles = 0;
  for (let frame = 0; frame < fps; frame++) particles += emissionCount(1 / fps, 46);
  assert.ok(particles > 34 && particles < 58, `signature trails vary with ${fps} FPS`);
}

ids.forEach((id, row) => {
  const weapon = WEAPONS.find((w) => w.id === id)!;
  const spec = FIRE_SPECS[id];
  const times = [
    100,
    spec.release * 0.8,
    spec.release,
    spec.release + 0.04,
    spec.release + 0.26,
    spec.duration + 0.2,
  ];
  const bounds = measureWeapon(weapon);
  const scale = Math.min(268 / bounds.w, 133 / bounds.h);
  let rest: Uint8ClampedArray | null = null;
  times.forEach((shotAge, column) => {
    const tile = createCanvas(320, 210);
    const ctx = tile.getContext("2d");
    ctx.save();
    ctx.translate(
      160 - (bounds.x + bounds.w / 2) * scale,
      114 - (bounds.y + bounds.h / 2) * scale,
    );
    ctx.scale(scale, scale);
    weapon.draw(ctx as unknown as CanvasRenderingContext2D, {
      t: 0.8,
      recoil: 0,
      charge: 0,
      shotAge,
      catchAge: 100,
      icon: true,
      discInFlight:
        id === "identityDisc" && shotAge >= spec.release && shotAge < 2,
    });
    ctx.restore();
    const pixels = ctx.getImageData(0, 0, 320, 210).data;
    if (column === 0) rest = new Uint8ClampedArray(pixels);
    if (column === 1 || column === 3)
      assert.notDeepEqual(
        pixels,
        rest,
        `${id}: no visible ${phases[column]} motion`,
      );
    context.drawImage(tile, column * 320, row * 210);
    context.fillStyle = weapon.accent;
    context.font = "600 12px sans-serif";
    context.fillText(
      column === 0 ? weapon.name : phases[column],
      column * 320 + 15,
      row * 210 + 22,
    );
    context.strokeStyle = "#2b3b45";
    context.strokeRect(column * 320, row * 210, 320, 210);
  });
  const alignment = makeGame();
  alignment.setWeapon(id);
  alignment.setPointer(alignment.cx, alignment.cy);
  alignment.time = 0.8;
  for (const age of [
    spec.release * 0.8,
    spec.release + 0.04,
    spec.release + 0.22,
  ]) {
    alignment.shotAge = age;
    const canvas = alignment.canvas as any;
    const ctx = canvas.getContext("2d");
    ctx.clearRect(0, 0, 1100, 700);
    ctx.save();
    ctx.translate(alignment.playerX(), alignment.playerY());
    ctx.rotate(alignment.aim);
    if (Math.cos(alignment.aim) < 0) ctx.scale(1, -1);
    ctx.scale(alignment.weaponScale(), alignment.weaponScale());
    weapon.draw(ctx, {
      t: alignment.time,
      recoil: 0,
      charge: 0,
      shotAge: age,
      catchAge: 100,
      discInFlight: id === "identityDisc" && age >= spec.release,
    });
    ctx.restore();
    const muzzle = alignment.muzzlePoint();
    const sample = ctx.getImageData(
      Math.floor(muzzle.x) - 2,
      Math.floor(muzzle.y) - 2,
      5,
      5,
    ).data;
    assert.ok(
      sample.some((value: number, i: number) => i % 4 === 3 && value > 90),
      `${id}: simulated muzzle left its moving emitter at ${age}s`,
    );
  }
  for (const fps of [30, 60, 144]) {
    const game = makeGame();
    game.setWeapon(id);
    game.setPointer(game.cx, game.cy);
    game.shoot();
    for (let f = 0; f < Math.floor(spec.release * 0.5 * fps); f++)
      game.update(1 / fps);
    assert.equal(
      game.hits,
      0,
      `${id}: deals damage before release at ${fps} fps`,
    );
    let maximumKick = 0;
    const cx = game.cx,
      cy = game.cy;
    for (let f = 0; f < fps * 1.35; f++) {
      game.update(1 / fps);
      maximumKick = Math.max(
        maximumKick,
        Math.hypot(game.cx - cx, game.cy - cy),
      );
    }
    assert.ok(
      game.hits >= 1 && game.hits <= (id === "identityDisc" ? 4 : 1),
      `${id}: incorrect hit count`,
    );
    assert.ok(
      maximumKick > 0.05 && maximumKick < 12,
      `${id}: target feedback missing or unbounded`,
    );
    game.render();
    const pose = fireMotion(id, spec.release + 0.04);
    assert.ok(Object.values(pose).every(Number.isFinite));
    const muzzle = firingMuzzleOffset(id, spec.release + 0.04);
    assert.ok(Number.isFinite(muzzle.x) && Number.isFinite(muzzle.y));
    assert.ok(game.marks.length >= 1, `${id}: firing motion missed the target emitter alignment`);
  }
  console.log(
    `PASS: ${id} anticipation, release, recoil, physical impact and single-shot scoring at 30/60/144 fps.`,
  );
});
writeFileSync(
  ".checks/signature-motion-sheet.png",
  sheet.toBuffer("image/png"),
);

function isolatedImpulse(id: keyof typeof FIRE_SPECS) {
  const game = makeGame();
  const initial = game.cy;
  game.pushTarget(game.cx, game.cy + game.wheelR, FIRE_SPECS[id].force);
  let peak = 0;
  for (let i = 0; i < 80; i++) {
    game.update(1 / 120);
    peak = Math.max(peak, Math.abs(game.cy - initial));
  }
  return peak;
}
assert.ok(
  isolatedImpulse("predatorShoulder") > isolatedImpulse("identityDisc") * 2.5,
);
assert.ok(isolatedImpulse("tripod") > isolatedImpulse("protonPack") * 1.8);
console.log(
  "PASS: actual target recoil preserves light/medium/heavy attack hierarchy.",
);

let caught = false;
for (const angle of [-2.8, -2.4, -2.05, -1.8, -1.4, -0.9, -0.4]) {
  const game = makeGame();
  game.setWeapon("identityDisc");
  game.setPointer(
    game.anchorX + Math.cos(angle) * 600,
    game.anchorY + Math.sin(angle) * 600,
  );
  let catchSeen = false;
  game.onState = (s) => {
    if (s.catchAge < 0.25) catchSeen = true;
  };
  game.shoot();
  for (let i = 0; i < 250; i++) game.update(1 / 60);
  assert.equal(game.bullets.length, 0);
  caught ||= catchSeen;
}
assert.ok(caught, "disc catch choreography never activates");
console.log(
  "PASS: thrown discs are caught with a real return signal; no immortal projectiles.",
);

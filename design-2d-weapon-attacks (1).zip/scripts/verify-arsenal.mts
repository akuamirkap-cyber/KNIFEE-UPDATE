import assert from "node:assert/strict";
import { createCanvas } from "@napi-rs/canvas";

Object.assign(globalThis, {
  window: { devicePixelRatio: 1 },
  document: { createElement: () => createCanvas(1, 1) },
});

const { Game, WEAPONS } = await import("../src/game/engine");
const { segmentCircleContact } = await import("../src/game/geometry");
const { rotatedWeaponBounds } = await import("../src/game/measure");
const { audio, emissionCount } = await import("../src/game/core");
audio.muted = true;

function gameAt(width = 1100, height = 700) {
  const canvas = createCanvas(width, height) as any;
  canvas.getBoundingClientRect = () => ({ width, height });
  const game = new Game(canvas);
  game.rotation = 0.2;
  game.dir = 1;
  return game;
}

function advance(game: InstanceType<typeof Game>, seconds: number, fps = 60) {
  for (let frame = 0; frame < Math.ceil(seconds * fps); frame++)
    game.update(1 / fps);
}

assert.equal(WEAPONS.length, 17);
assert.equal(new Set(WEAPONS.map((w) => w.id)).size, 17);
for (const weapon of WEAPONS) {
  const game = gameAt();
  game.setWeapon(weapon.id);
  for (const angle of [-2.9, -2.1, -Math.PI / 2, -0.6, -0.2]) {
    game.aim = angle;
    const b = rotatedWeaponBounds(weapon, angle);
    const scale = game.weaponScale();
    assert.ok(
      game.playerX() + b.minX * scale >= 18,
      `${weapon.id}: clipped on the left`,
    );
    assert.ok(
      game.playerX() + b.maxX * scale <= game.W - 18,
      `${weapon.id}: clipped on the right`,
    );
    assert.ok(
      game.playerY() + b.maxY * scale <= game.H - 30,
      `${weapon.id}: clipped at the bottom`,
    );
  }
}
console.log("PASS: weapon silhouettes fit the arena at five aiming angles.");
assert.equal(segmentCircleContact(0, 0, 100, 0, 50, 0, 10), 0.4);
assert.equal(segmentCircleContact(0, 20, 100, 20, 50, 0, 10), null);
for (const fps of [30, 60, 144]) {
  let particles = 0;
  for (let frame = 0; frame < fps * 10; frame++)
    particles += emissionCount(1 / fps, 360);
  assert.ok(
    particles > 3420 && particles < 3780,
    `particle emission depends on ${fps} fps`,
  );
}
console.log("PASS: particle density remains consistent across refresh rates.");

for (const [width, height] of [
  [1100, 700],
  [390, 650],
  [760, 360],
  [844, 210],
]) {
  for (const fps of [30, 60, 144]) {
    for (const weapon of WEAPONS) {
      const game = gameAt(width, height);
      game.setWeapon(weapon.id);
      game.setPointer(game.cx, game.cy);
      game.charge = 0.8;
      game.shoot();
      assert.equal(game.ammo, 8, `${weapon.id}: one click must use one shot`);
      advance(game, 0.8, fps);
      assert.ok(
        game.hits >= 1,
        `${weapon.id} missed at ${fps}fps, ${width}x${height}`,
      );
      game.render();
      for (const p of game.particles) {
        assert.ok(
          [p.x, p.y, p.life, p.size].every(Number.isFinite),
          `${weapon.id}: invalid particle`,
        );
      }
    }
  }
}
console.log(
  "PASS: 17 weapons fire, hit, and render at 30/60/144 fps on desktop, portrait, and compact landscape.",
);

for (const weapon of WEAPONS) {
  const canvas = createCanvas(160, 140);
  const ctx = canvas.getContext("2d");
  const mark = {
    weapon,
    a: 0,
    r: 100,
    size: weapon.markSize,
    age: 25,
    seed: 14.7,
  };
  const draw = () => {
    ctx.clearRect(0, 0, 160, 140);
    ctx.save();
    ctx.translate(72, 70);
    weapon.drawMark(ctx as unknown as CanvasRenderingContext2D, mark, 26);
    ctx.restore();
    return ctx.getImageData(0, 0, 160, 140).data;
  };
  const first = new Uint8ClampedArray(draw());
  assert.ok(
    first.some((value, i) => i % 4 === 3 && value > 24),
    `${weapon.id}: marker disappeared after cooling`,
  );
  assert.deepEqual(
    draw(),
    first,
    `${weapon.id}: marker shape changes randomly between identical frames`,
  );
}
console.log(
  "PASS: all 17 material-specific marks remain visible after cooling and are deterministic.",
);

const plasmaGame = gameAt();
plasmaGame.setPointer(plasmaGame.cx, plasmaGame.cy);
plasmaGame.shoot();
assert.equal(plasmaGame.bullets[0].kind, "predatorPlasma");
advance(plasmaGame, 0.2);
assert.equal(plasmaGame.hits, 0);
assert.equal(plasmaGame.bullets[0].data.launched, 0);
advance(plasmaGame, 0.6);
assert.equal(plasmaGame.hits, 1);
assert.equal(plasmaGame.marks[0].weapon.id, "predatorShoulder");
console.log(
  "PASS: Predator charge delays the shot, then launches plasma and leaves one permanent scar.",
);

const blockedGame = gameAt();
blockedGame.setWeapon("identityDisc");
const x = blockedGame.cx;
const y = blockedGame.cy + blockedGame.wheelR;
assert.equal(blockedGame.registerHit(x, y, blockedGame.weapon, 101), true);
assert.equal(blockedGame.registerHit(x, y, blockedGame.weapon, 101), true);
assert.equal(blockedGame.hits, 1);
assert.equal(blockedGame.registerHit(x, y, blockedGame.weapon, 102), false);
assert.equal(blockedGame.state, "lost");
console.log(
  "PASS: disc scars still block subsequent throws; a ricochet cannot score twice on its own scar.",
);

let maxHits = 0;
for (let i = 0; i < 18; i++) {
  const game = gameAt(960, 620);
  game.setWeapon("identityDisc");
  const a = -2.05 + i * 0.055;
  game.setPointer(
    game.anchorX + Math.cos(a) * 500,
    game.anchorY + Math.sin(a) * 500,
  );
  game.shoot();
  advance(game, 4);
  assert.ok(game.hits <= 4);
  assert.equal(game.bullets.length, 0);
  maxHits = Math.max(maxHits, game.hits);
}
assert.ok(
  maxHits >= 2,
  "disc no longer ricochets into multiple unmarked surfaces",
);
console.log(
  `PASS: disc multi-hit, return/lifetime, and four-hit cap preserved (observed ${maxHits} hits).`,
);

for (const id of ["ak47", "identityDisc", "predatorShoulder"]) {
  const game = gameAt();
  game.setWeapon(id);
  game.ammo = 1;
  game.setPointer(game.anchorX + 700, game.anchorY - 100);
  game.shoot();
  advance(game, 5);
  assert.equal(game.state, "lost", `${id}: empty ammo never resolved`);
  assert.equal(game.message, "AMUNISI HABIS");
  game.reset();
  advance(game, 2);
  assert.equal(
    game.state,
    "ready",
    `${id}: stale game-over work survived reset`,
  );
}
console.log(
  "PASS: last-shot, returning-disc ammo exhaustion, and reset cleanly finish.",
);

const pauseGame = gameAt();
pauseGame.setPointer(pauseGame.cx, pauseGame.cy);
pauseGame.shoot();
advance(pauseGame, 0.1);
pauseGame.setPaused(true);
const snapshot = {
  rotation: pauseGame.rotation,
  time: pauseGame.time,
  elapsed: pauseGame.elapsed,
  age: pauseGame.bullets[0].age,
  ammo: pauseGame.ammo,
};
advance(pauseGame, 2);
pauseGame.pressDown();
assert.deepEqual(
  {
    rotation: pauseGame.rotation,
    time: pauseGame.time,
    elapsed: pauseGame.elapsed,
    age: pauseGame.bullets[0].age,
    ammo: pauseGame.ammo,
  },
  snapshot,
);
pauseGame.setPaused(false);
advance(pauseGame, 0.8);
assert.equal(pauseGame.hits, 1);
pauseGame.reducedMotion = true;
pauseGame.shakeAmt = 0;
pauseGame.shake(30);
assert.equal(pauseGame.shakeAmt, 0);
console.log(
  "PASS: pause freezes physics, timers and input; reduced-motion disables camera shake.",
);

const bowGame = gameAt();
bowGame.setWeapon("bow");
bowGame.cooldownT = 0.3;
bowGame.charging = true;
bowGame.charge = 0.9;
bowGame.pressUp();
advance(bowGame, 0.31);
assert.equal(bowGame.ammo, 8);
assert.ok(
  Math.hypot(bowGame.bullets[0]?.vx ?? 0, bowGame.bullets[0]?.vy ?? 0) > 1300,
  "queued bow release lost its charge",
);
console.log("PASS: a queued bow release retains the original draw strength.");

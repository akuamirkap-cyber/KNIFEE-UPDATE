import assert from "node:assert/strict";
import { mkdirSync, writeFileSync } from "node:fs";
import { chromium } from "@playwright/test";

mkdirSync(".checks", { recursive: true });
const browser = await chromium.launch({
  headless: true,
  args: ["--no-sandbox"],
});
const page = await browser.newPage({
  viewport: { width: 1440, height: 960 },
  deviceScaleFactor: 1,
});
const errors: string[] = [];
page.on("pageerror", (error) => errors.push(error.message));
await page.goto("http://localhost:5173", { waitUntil: "networkidle" });
await page.locator("main canvas").waitFor();
await page.waitForTimeout(600);
assert.equal(
  await page
    .locator('[data-weapon-id="predatorShoulder"]')
    .getAttribute("aria-pressed"),
  "true",
);
await page.screenshot({ path: ".checks/browser-desktop.png" });
const canvas = await page.locator("main canvas").boundingBox();
assert.ok(canvas);
await page.mouse.click(
  canvas.x + canvas.width / 2,
  canvas.y + canvas.height * 0.33,
);
await page.waitForTimeout(100);
await page.screenshot({ path: ".checks/browser-charge.png" });
await page.waitForTimeout(650);
assert.match(
  (await page.locator(".hit-counter").getAttribute("aria-label")) ?? "",
  /^1\/7 /,
);
await page.screenshot({ path: ".checks/browser-impact.png" });

for (const id of [
  "plasmacaster",
  "identityDisc",
  "protonPack",
  "tripod",
  "repulsor",
  "predatorShoulder",
]) {
  await page.locator(`[data-weapon-id="${id}"]`).click();
  await page.getByRole("button", { name: "Reset (R)" }).click();
  await page.waitForTimeout(100);
  await page.screenshot({ path: `.checks/browser-${id}.png` });
  await page.keyboard.press("Space");
  await page.waitForTimeout(80);
  assert.ok(
    Number(
      await page
        .locator(".weapon-showcase canvas")
        .getAttribute("data-shot-age"),
    ) < 0.4,
    `${id}: preview does not receive the live firing state`,
  );
  await page.screenshot({ path: `.checks/browser-${id}-attack.png` });
  await page.waitForTimeout(240);
  await page.screenshot({ path: `.checks/browser-${id}-impact-peak.png` });
  await page.waitForTimeout(650);
  const hits = Number(
    (
      (await page.locator(".hit-counter").getAttribute("aria-label")) ?? ""
    ).split("/")[0],
  );
  assert.ok(hits >= 1 && hits <= (id === "identityDisc" ? 4 : 1));
}

// Collection filters, keyboard tabs, and input recovery after a native dialog.
await page.getByRole("tab", { name: "Balistik", exact: true }).click();
assert.equal(await page.locator("[data-weapon-id]").count(), 4);
await page.keyboard.press("ArrowRight");
assert.equal(
  await page
    .getByRole("tab", { name: "Energi", exact: true })
    .getAttribute("aria-selected"),
  "true",
);
assert.equal(await page.locator("[data-weapon-id]").count(), 9);
await page.getByRole("tab", { name: "Ikonik", exact: true }).click();
assert.equal(await page.locator("[data-weapon-id]").count(), 4);
await page.getByRole("tab", { name: "Semua", exact: true }).click();
assert.equal(await page.locator("[data-weapon-id]").count(), 17);
await page.getByRole("button", { name: "Reset (R)", exact: true }).click();
await page
  .getByRole("button", { name: "Panduan kontrol", exact: true })
  .click();
await page.getByRole("dialog", { name: "Panduan & pengaturan" }).waitFor();
await page.screenshot({ path: ".checks/browser-guide.png" });
assert.equal(
  await page.getByRole("checkbox", { name: /Getaran kamera/ }).isChecked(),
  true,
);
await page.getByRole("checkbox", { name: /Getaran kamera/ }).uncheck();
assert.equal(
  await page.evaluate(() => localStorage.getItem("arsenal.cinematic")),
  "false",
);
await page.getByRole("checkbox", { name: /Getaran kamera/ }).check();
await page.keyboard.press("Escape");
await page.waitForTimeout(100);
assert.equal(
  await page.evaluate(() => document.activeElement?.tagName),
  "CANVAS",
);

// A real seven-shot run verifies the result screen, timer and best-time persistence.
await page.locator('[data-weapon-id="ak47"]').click();
await page.getByRole("button", { name: "Reset (R)", exact: true }).click();
for (let shot = 0; shot < 7; shot++) {
  await page.keyboard.press("Space");
  await page.waitForTimeout(480);
  if (shot === 1) {
    await page.keyboard.press("KeyP");
    await page.getByRole("region", { name: "Permainan dijeda" }).waitFor();
    const frozen = await page
      .locator("main canvas")
      .evaluate((canvas) => (canvas as HTMLCanvasElement).toDataURL());
    await page.waitForTimeout(350);
    assert.equal(
      await page
        .locator("main canvas")
        .evaluate((canvas) => (canvas as HTMLCanvasElement).toDataURL()),
      frozen,
    );
    await page.screenshot({ path: ".checks/browser-pause.png" });
    await page.keyboard.press("KeyP");
  }
}
await page.getByRole("region", { name: "Level selesai" }).waitFor();
assert.ok(
  Number(await page.evaluate(() => localStorage.getItem("arsenal.bestTime"))) >
    0,
);
await page.screenshot({ path: ".checks/browser-level-clear.png" });
await page.getByRole("button", { name: "Main lagi", exact: true }).click();
assert.match(
  (await page.locator(".hit-counter").getAttribute("aria-label")) ?? "",
  /^0\/7 /,
);

// Deliberately miss all shots and confirm the retry action works.
const missCanvas = await page.locator("main canvas").boundingBox();
assert.ok(missCanvas);
await page.mouse.move(
  missCanvas.x + missCanvas.width - 20,
  missCanvas.y + missCanvas.height * 0.72,
);
for (let shot = 0; shot < 9; shot++) {
  await page.keyboard.press("Space");
  await page.waitForTimeout(220);
}
await page.getByRole("region", { name: "Sesi berakhir" }).waitFor();
await page.screenshot({ path: ".checks/browser-retry.png" });
await page.getByRole("button", { name: "Main lagi", exact: true }).click();

await page.getByRole("button", { name: "Matikan suara", exact: true }).click();
assert.equal(
  await page.evaluate(() => localStorage.getItem("arsenal.muted")),
  "true",
);
await page.getByRole("button", { name: "Nyalakan suara", exact: true }).click();

if (await page.evaluate(() => document.fullscreenEnabled)) {
  await page.getByRole("button", { name: "Layar penuh", exact: true }).click();
  await page.waitForFunction(() => Boolean(document.fullscreenElement));
  await page
    .getByRole("button", { name: "Keluar layar penuh", exact: true })
    .click();
  await page.waitForFunction(() => !document.fullscreenElement);
}

await page.emulateMedia({ reducedMotion: "reduce" });
await page
  .getByRole("button", { name: "Panduan kontrol", exact: true })
  .click();
assert.equal(
  await page.getByRole("checkbox", { name: /Getaran kamera/ }).isDisabled(),
  true,
);
await page.keyboard.press("Escape");
await page.emulateMedia({ reducedMotion: "no-preference" });

for (const [width, height] of [
  [320, 568],
  [390, 844],
  [844, 390],
]) {
  await page.setViewportSize({ width, height });
  await page.locator('[data-weapon-id="predatorShoulder"]').click();
  await page.getByRole("button", { name: "Reset (R)" }).click();
  await page.waitForTimeout(300);
  const overflow = await page.evaluate(
    () => document.documentElement.scrollWidth > window.innerWidth,
  );
  assert.equal(
    overflow,
    false,
    `${width}x${height} has horizontal document overflow`,
  );
  await page.keyboard.press("Space");
  await page.waitForTimeout(800);
  assert.match(
    (await page.locator(".hit-counter").getAttribute("aria-label")) ?? "",
    /^1\/7 /,
  );
  await page.screenshot({ path: `.checks/browser-${width}x${height}.png` });
}

// Render the actual Web Audio synthesis offline; detect silence, NaNs and hard clipping.
await page.evaluate("globalThis.__name = fn => fn");
const soundResults = await page.evaluate(async () => {
  const { audio } = await import("/src/game/core.ts" as string);
  const OriginalAudioContext = window.AudioContext;
  const results: {
    kind: string;
    peak: number;
    rms: number;
    finite: boolean;
  }[] = [];
  const soundKinds = [
    "caster-charge",
    "caster-shot",
    "caster-hit",
    "disc-windup",
    "disc",
    "disc-bounce",
    "disc-catch",
    "proton-start",
    "proton-hit",
    "martian-charge",
    "martian-hit",
    "repulsor-charge",
    "repulsor-hit",
    "predator-charge",
    "predator-shot",
    "predator-impact",
    "proton",
    "martian",
    "repulsor",
  ];
  for (const kind of soundKinds) {
    const context = new OfflineAudioContext(1, 72000, 48000);
    context.resume = () => Promise.resolve();
    Object.defineProperty(window, "AudioContext", {
      configurable: true,
      writable: true,
      value: function () {
        return context;
      },
    });
    const Synth = audio.constructor as new () => {
      play: (kind: string) => void;
    };
    const synth = new Synth();
    synth.play(kind);
    const buffer = await context.startRendering();
    const samples = buffer.getChannelData(0);
    let peak = 0;
    let sum = 0;
    let finite = true;
    for (const sample of samples) {
      finite &&= Number.isFinite(sample);
      peak = Math.max(peak, Math.abs(sample));
      sum += sample * sample;
    }
    results.push({ kind, peak, rms: Math.sqrt(sum / samples.length), finite });
  }
  Object.defineProperty(window, "AudioContext", {
    configurable: true,
    writable: true,
    value: OriginalAudioContext,
  });
  return results;
});
for (const sound of soundResults) {
  assert.ok(
    sound.finite && sound.rms > 0.001 && sound.peak < 0.99,
    `invalid sound: ${JSON.stringify(sound)}`,
  );
}

const liveMuteRms = await page.evaluate(async () => {
  const { audio } = await import("/src/game/core.ts" as string);
  const original = window.AudioContext;
  const context = new OfflineAudioContext(1, 48000, 48000);
  context.resume = () => Promise.resolve();
  Object.defineProperty(window, "AudioContext", {
    configurable: true,
    writable: true,
    value: function () {
      return context;
    },
  });
  const Synth = audio.constructor as new () => {
    play: (kind: string) => void;
    muted: boolean;
  };
  const synth = new Synth();
  synth.play("proton");
  synth.muted = true;
  const samples = (await context.startRendering()).getChannelData(0);
  let sum = 0;
  for (let i = 4800; i < samples.length; i++) sum += samples[i] * samples[i];
  Object.defineProperty(window, "AudioContext", {
    configurable: true,
    writable: true,
    value: original,
  });
  return Math.sqrt(sum / (samples.length - 4800));
});
assert.ok(liveMuteRms < 0.0001, "mute did not fade an already-playing sound");
writeFileSync(
  ".checks/audio-verification.json",
  JSON.stringify(soundResults, null, 2),
);
assert.deepEqual(errors, [], "browser runtime errors");
console.log(
  "PASS: responsive gameplay, filtering, keyboard navigation, pause, guides, fullscreen, reduced motion, win/retry, persistence and live audio muting.",
);
console.table(soundResults);
await browser.close();

import { createCanvas } from '@napi-rs/canvas';
import { mkdirSync, writeFileSync } from 'node:fs';

Object.assign(globalThis, {
  window: { devicePixelRatio: 1 },
  document: { createElement: () => createCanvas(1, 1) },
});

const { WEAPONS, Game } = await import('../src/game/engine');
const { measureWeapon } = await import('../src/game/measure');
mkdirSync('.checks', { recursive: true });

function models(ids: string[], filename: string, cols: number, cellWidth: number, cellHeight: number) {
  const canvas = createCanvas(cols * cellWidth, Math.ceil(ids.length / cols) * cellHeight);
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#0b1320';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  for (let i = 0; i < ids.length; i++) {
    const weapon = WEAPONS.find((w) => w.id === ids[i])!;
    const bx = (i % cols) * cellWidth;
    const by = Math.floor(i / cols) * cellHeight;
    const bounds = measureWeapon(weapon);
    const scale = Math.min((cellWidth - 65) / bounds.w, (cellHeight - 80) / bounds.h, 1.7);
    ctx.save();
    ctx.translate(bx + cellWidth / 2 - (bounds.x + bounds.w / 2) * scale, by + cellHeight / 2 - (bounds.y + bounds.h / 2) * scale + 8);
    ctx.scale(scale, scale);
    weapon.draw(ctx as unknown as CanvasRenderingContext2D, { t: 0.8, recoil: 0, charge: 0.35, icon: true, shotAge: 100 });
    ctx.restore();
    ctx.fillStyle = weapon.accent;
    ctx.font = '600 17px sans-serif';
    ctx.fillText(weapon.name, bx + 22, by + 29);
    ctx.strokeStyle = '#263142';
    ctx.lineWidth = 1;
    ctx.strokeRect(bx + 0.5, by + 0.5, cellWidth - 1, cellHeight - 1);
  }
  writeFileSync(`.checks/${filename}.png`, canvas.toBuffer('image/png'));
}

models(['protonPack', 'tripod', 'repulsor', 'predatorShoulder'], 'signature-models', 2, 600, 340);
models(WEAPONS.map((w) => w.id), 'all-models', 4, 400, 235);

const cols = 4;
const cw = 260;
const ch = 275;
const canvas = createCanvas(cols * cw, Math.ceil(WEAPONS.length / cols) * ch);
const ctx = canvas.getContext('2d');
ctx.fillStyle = '#0d1624';
ctx.fillRect(0, 0, canvas.width, canvas.height);
WEAPONS.forEach((weapon, i) => {
  const cv = createCanvas(cw, ch) as any;
  cv.getBoundingClientRect = () => ({ width: cw, height: ch });
  const game = new Game(cv) as any;
  game.cx = cw / 2;
  game.cy = ch / 2 + 14;
  game.wheelR = 90;
  game.time = 2.3;
  game.rotation = 0;
  game.marks = Array.from({ length: 5 }, (_, j) => ({ weapon, a: j * Math.PI * 2 / 5 - Math.PI / 2, r: 90, size: weapon.markSize, age: 2.6, seed: 21 + j * 0.7 }));
  game.drawWheel(cv.getContext('2d'));
  ctx.drawImage(cv, (i % cols) * cw, Math.floor(i / cols) * ch);
  ctx.font = '600 13px sans-serif';
  ctx.fillStyle = weapon.accent;
  ctx.fillText(weapon.name, (i % cols) * cw + 14, Math.floor(i / cols) * ch + 25);
});
writeFileSync('.checks/wheel-marks.png', canvas.toBuffer('image/png'));
console.log('Rendered model sheets and all weapon marks in .checks/');